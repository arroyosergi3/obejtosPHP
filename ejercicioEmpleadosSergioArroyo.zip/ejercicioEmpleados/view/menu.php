<?php session_start(); ?>
<form action="../controller/cerrarSesion.php" method="POST">
    <input type="submit" name="salir" value="Cerrar Sesion">
</form>
<a href="nuevaTarea.php">Nueva Tarea</a><br>
<a href="actualizaTarea.php">Actualiza Tarea</a><br>
